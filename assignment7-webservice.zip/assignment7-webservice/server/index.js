const express = require("express");
const app = express()
const response = [
    {
        name: "Rushikesh Waman",
        email: "rushikesh@gmail.com"
    },
    {
        name: "Rushikesh Waman",
        email: "rushikesh@gmail.com"
    },
    {
       name: "Rushikesh Waman",
        email: "rushikesh@gmail.com"
    },
];
app.get("/users", (req, res) => {
    res.json(response);
})


app.listen(5000, () => {
    console.log("listening on port 5000");
})